package database;  // sınıfın hangi pakette olduğunu belirtir.

import java.util.HashMap; // HashMap sınıfını kullanabilmek için bu sınıfı importladık

public class Satır {
	HashMap<String, String> data = new HashMap<>();  // Her bir satırın verilerini saklamak için bir HashMap oluşturduk

    public void set(String column, String value) {
        data.put(column, value);	// Parametre olarak (column ve value) alınan sütun adı ve değeri, HashMap'e ekledik
    }

    public String get(String column) {
        return data.get(column);  // Parametre olarak alınan sütun adının değerini HashMap'den çeker ve döndürür.
    }

	public Satır get(int i) {
		// TODO Auto-generated method stub
		return null; // Bu metod her zaman null döndürür. satır döndürmeye yarar. Önemlidir!!
	}
}
