package database;	// sınıfın hangi pakette olduğunu belirtir.

import java.util.ArrayList; //ArrayList sınıfını kullanabilmek için bu sınıfı importladık

public class Tablo {
	 String name;
	    ArrayList<Sutun> columns = new ArrayList<>(); // Tablonun sütunlarını saklamak için bir ArrayList oluşturduk.
	    ArrayList<Satır> rows = new ArrayList<>(); // Tablonun satirlarını saklamak için bir ArrayList oluşturduk

	    public Tablo(String name) { // yapıcı metod constructor ile atama yapıyoruz.
	        this.name = name;
	    }

	    public Satır newRow() {
	        return new Satır(); // Yeni bir Satır nesnesi oluşturur ve bu nesneyi döndürür
	    }

		public Satır rows() { 
			return null; // Bu metod her zaman null döner
		}
}
