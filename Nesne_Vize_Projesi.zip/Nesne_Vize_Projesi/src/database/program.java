package database;


public class program {
    public static void main(String[] args) {
    	// Tablo oluştur
        Tablo table = new Tablo("Personel");

        
        // Tabloya sütunlar ekle
        String[] columnNames = {"Id ", "İsim ", "Soyisim", "Yaş ", "Departman ", "İletişim", "Cinsiyet ", "Okul No"};
        for (String columnName : columnNames) {
            table.columns.add(new Sutun(columnName));
        }
        

        // Kendi belirlediğiniz değerlerle 3 satır oluştur ve tabloya ekle
        String[][] rows = {
            {"1", "Uğur Can", "Uçar", "21", "Öğrenci Bil. Müh", "ucarugur57@gmail.com", "Erkek", "202113709067"},
            {"2", "Mehmet Ali", "Şahin", "22", "Öğrenci Bil. Müh", "aslanshn.09@gmail.com", "Erkek", "111111111111"}, // okul no sonradan güncellendi
            {"3", "Furkan", "Emiri", "21", "Öğrenci Bil. Müh", "emirifurkan.08@gmail.com", "Erkek", "202113709006"}
        };	 
        for (String[] rowValues : rows) {
            Satır row = table.newRow();
            for (int i = 0; i < columnNames.length; i++) {
                row.set(columnNames[i], rowValues[i]);
            }
            table.rows.add(row);
        }
       
        
        // Yeni bir sütun oluştur
        Sutun yeniSutun = new Sutun("Maaş");
        // Yeni sütunu tabloya ekle
        table.columns.add(yeniSutun); // Son olarak eklediğimiz sütunun değerleri girilmediğinden default değer olarak null olacaktır.
        
        
        // İndeksi 1 olanın okul no değerinin saklıyorum. (Eski değer)
        String eski_deger = rows[1][7]; // Burada [1] id 2 olanı, [7] ise okul no alanını seçer
        
        // 2.Satırdaki değerlerden okul no değerini "202113709048" olarak günceller
        Satır guncellenenSatir = table.rows.get(1);
        guncellenenSatir.set("Okul No", "202113709048");
        
        // Yeni değeri sakla
        String yeniDeger = guncellenenSatir.get("Okul No");
       
        
        // Tabloyu yazdır
        EkranaYazdir.yazdir(table);
        
        System.out.println(); // Tablo ile arasında bir boşluk bıraktım.
        // Eski ve yeni değerleri yazdır
        System.out.printf("Eski değer: %s, Yeni değer: %s\n", eski_deger, yeniDeger);
        System.out.println();	 // bir boşluk bıraktım.
        System.out.println("GİtHub Linki -> https://github.com/ugurcn4/OOP_vize");
    }
}
