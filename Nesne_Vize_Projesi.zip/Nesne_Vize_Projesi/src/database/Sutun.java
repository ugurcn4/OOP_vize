package database;  // sınıfın hangi pakette olduğunu belirtir.

public class Sutun {
	String name;  // Sütunun adını saklamak için bir String değişkeni tanımlarız

    public Sutun(String name) { //yapıcı metod constructor ile atama yapıyoruz.
        this.name = name; // this ANAHTAR sözcüğü önemlidir. Olmazsa kodda karışıklık olabilir. Önemli!!! 
    }
}
