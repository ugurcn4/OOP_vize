package database;  // sınıfın hangi pakette olduğunu belirtir.

public class EkranaYazdir {	 // EkranaYazdir adında bir public sınıf tanımladık.
	public static void yazdir(Tablo table) {// yazdir adında, Tablo tipinde bir parametre alan ve void dönen bir public static metod tanımladık
	    	 // Tablo ismini yazdır
	        System.out.println(table.name);

	        // Sütun isimlerini ve değerleri düzgün bir şekilde yazdır
	        int[] columnWidths = new int[table.columns.size()];  // Her bir sütunun genişliğini saklamak için bir dizi oluştururuz.
	        
	        for (int i = 0; i < table.columns.size(); i++) {  
	        } // Her bir sütunun adının uzunluğunu hesaplar ve bunu columnWidths dizisinde saklarız.
	        for (Satır row : table.rows) {
	            for (int i = 0; i < table.columns.size(); i++) {
	                String value = row.get(table.columns.get(i).name);
	                columnWidths[i] = Math.max(columnWidths[i], value != null ? value.length() : 0);
	            }
	        }
	        
	        for (int i = 0; i < table.columns.size(); i++) { // Her bir sütunun adını hesaplanan genişlikte ekrana yazdırırız.
	            System.out.printf("%-" + (columnWidths[i] + 2) + "s", table.columns.get(i).name);
	        }
	        System.out.println();
	        for (Satır row : table.rows) {
	            for (int i = 0; i < table.columns.size(); i++) {
	                String value = row.get(table.columns.get(i).name);
	                System.out.printf("%-" + (columnWidths[i] + 2) + "s", value);
	            }
	            System.out.println(); // Her bir satırdan sonra bir satır boşluk bıraktık.

	        }
	    }
	    
}


